import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter/cupertino.dart';
import 'routers/approutes.dart';
import 'utils/themes/themeprovider.dart';
import 'utils/sf_manager.dart'; // Add this import for SfManager

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

// Add AuthProvider class for authentication management
class AuthProvider extends ChangeNotifier {
  String? _token;
  String? _userId;
  bool _isInitialized = false;

  String? get token => _token;
  String? get userId => _userId;
  bool get isLoggedIn => _token != null;
  bool get isInitialized => _isInitialized;

  AuthProvider() {
    _initAuth();
  }

  Future<void> _initAuth() async {
    _token = await SfManager.getToken();
    _userId = await SfManager.getUserId();
    _isInitialized = true;
    notifyListeners();
  }

  Future<void> login(String token, String userId) async {
    await SfManager.setToken(token);
    await SfManager.setUserId(userId);
    _token = token;
    _userId = userId;
    notifyListeners();
  }

  Future<void> logout() async {
    await SfManager.clearToken();
    await SfManager.clearUserId();
    _token = null;
    _userId = null;
    notifyListeners();
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: themeProvider.lightTheme,
          darkTheme: themeProvider.darkTheme,
          themeMode:
              themeProvider.isDarkMode ? ThemeMode.dark : ThemeMode.light,
          initialRoute: AppRoutes.splash,
          onGenerateRoute: AppRoutes.onGenerateRoute,
          onGenerateInitialRoutes: (initialRoute) {
            return [
              AppRoutes.onGenerateRoute(
                const RouteSettings(name: AppRoutes.splash),
              )!,
            ];
          },
          onUnknownRoute: (settings) {
            return MaterialPageRoute(
              builder: (context) => Scaffold(
                appBar: AppBar(
                  title: const Text('Error'),
                ),
                body: Center(
                  child: Text(
                    'Route not found: ${settings.name}',
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
