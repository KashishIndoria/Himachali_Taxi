import 'package:himachali_taxi/utils/sf_manager.dart';

/// Gets the stored authentication token
Future<String?> getToken() async {
  return await SfManager.getToken();
}

/// Gets the stored user ID
Future<String?> getUserId() async {
  return await SfManager.getUserId();
}

/// Gets the user role with a default fallback value
Future<String> getUserRole() async {
  final role = await SfManager.getUserRole();
  return role ?? 'user'; // Default to user role if not set
}

/// Saves all authentication data at once
Future<void> saveAuthData(String token, String userId, String role) async {
  await SfManager.setToken(token);
  await SfManager.setUserId(userId);
  await SfManager.setUserRole(role);
}
