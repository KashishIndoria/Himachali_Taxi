import 'package:himachali_taxi/utils/sf_manager.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AuthService {
  static const String _baseUrl = 'http://10.0.2.2:3000/api/auth';

  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
    String role = 'user',
  }) async {
    try {
      print('Making login request...');
      final response = await http.post(
        Uri.parse('$_baseUrl/${role}/login'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'password': password,
        }),
      );

      print('Login Response Status: ${response.statusCode}');
      print('Login Response Body: ${response.body}');

      final data = json.decode(response.body);

      if (response.statusCode != 200) {
        throw Exception(data['message'] ?? 'Login failed');
      }
      return data;
    } catch (e) {
      print('Login error: $e');
      throw Exception('Failed to login: $e');
    }
  }

  Future<void> logout() async {
    try {
      await SfManager.clearAll();
    } catch (e) {
      print('Logout error: $e');
      throw Exception('Failed to logout: $e');
    }
  }

  Future<bool> isAuthenticated() async {
    final token = await SfManager.getToken();
    return token != null;
  }

  Future<Map<String, String?>> getAuthData() async {
    return {
      'token': await SfManager.getToken(),
      'userId': await SfManager.getUserId(),
    };
  }

  Future<Map<String, dynamic>> verifyOTP({
    required String email,
    required String otp,
    required String role,
    required Map<String, dynamic> userData,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/verify-otp'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'otp': otp,
          'role': role, // Add role to the request
        }),
      );

      print('OTP Verification Response: ${response.body}');

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        final errorData = json.decode(response.body);
        throw Exception(errorData['message'] ?? 'OTP verification failed');
      }
    } catch (e) {
      print('OTP Verification Error: $e');
      throw Exception('Failed to verify OTP: $e');
    }
  }

  Future<void> resendOTP({required String email}) async {
    try {
      // Implement your API call here
      await Future.delayed(const Duration(seconds: 1)); // Simulated API call
    } catch (e) {
      throw Exception('Failed to resend OTP: $e');
    }
  }

  // ...existing code...

  Future<Map<String, dynamic>> signup({
    required String email,
    required String password,
    required Map<String, dynamic> userData,
  }) async {
    try {
      print('Attempting signup...');
      final String endpoint = userData['role'] == 'captain'
          ? '$_baseUrl/captain/signup'
          : '$_baseUrl/user/signup';

      final response = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          ...userData,
          'email': email,
          'password': password,
        }),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201) {
        return json.decode(response.body);
      } else {
        final errorData = json.decode(response.body);
        throw Exception(errorData['message'] ?? 'Signup failed');
      }
    } catch (e) {
      print('Signup error details: $e');
      if (e.toString().contains('<!DOCTYPE html>')) {
        throw Exception('Server connection error. Please try again later.');
      }
      throw Exception('Failed to sign up: $e');
    }
  }
}
