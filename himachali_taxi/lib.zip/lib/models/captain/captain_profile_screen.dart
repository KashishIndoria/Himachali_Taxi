import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:himachali_taxi/models/captain/captainNavBAr.dart';
import 'package:himachali_taxi/models/user/profileimagehero.dart';
import 'package:himachali_taxi/utils/supabase_manager.dart';
import 'package:himachali_taxi/utils/themes/colors.dart';
import 'package:himachali_taxi/utils/themes/themeprovider.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:intl/intl.dart' as intl;

class CaptainProfileScreen extends StatefulWidget {
  final String userId;
  final String token;

  const CaptainProfileScreen({
    Key? key,
    required this.userId,
    required this.token,
  }) : super(key: key);

  @override
  _CaptainProfileScreenState createState() => _CaptainProfileScreenState();
}

class _CaptainProfileScreenState extends State<CaptainProfileScreen>
    with SingleTickerProviderStateMixin {
  // Form Controllers
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  // Vehicle Controllers
  final TextEditingController _vehicleMakeController = TextEditingController();
  final TextEditingController _vehicleModelController = TextEditingController();
  final TextEditingController _vehicleYearController = TextEditingController();
  final TextEditingController _vehicleColorController = TextEditingController();
  final TextEditingController _vehicleLicensePlateController =
      TextEditingController();

  // License Controllers
  final TextEditingController _licenseNumberController =
      TextEditingController();
  final TextEditingController _licenseStateController = TextEditingController();

  // State variables
  String? _profileImage;
  DateTime? _licenseExpiry;
  bool _isEmailVerified = false;
  bool _isLicenseVerified = false;
  bool _isLoading = true;
  bool _isUploading = false;
  bool _isEditing = false;

  // Statistics
  double _rating = 0.0;
  int _totalRides = 0;
  double _totalEarnings = 0.0;
  String _accountStatus = 'pending';

  // Tab controller for profile sections
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _fetchCaptainData();
  }

  Future<void> _fetchCaptainData() async {
    try {
      setState(() => _isLoading = true);

      final response = await http.get(
        Uri.parse('http://10.0.2.2:3000/api/captain/profile'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.token}',
        },
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final captainData = responseData['captain'];

        setState(() {
          // Personal info
          _firstNameController.text = captainData['firstName'] ?? '';
          _lastNameController.text = captainData['lastName'] ?? '';
          _emailController.text = captainData['email'] ?? '';
          _phoneController.text = captainData['phone'] ?? '';
          _profileImage = captainData['profileImage'];
          _isEmailVerified = captainData['isVerified'] ?? false;

          // Vehicle info
          final vehicleDetails = captainData['vehicleDetails'] ?? {};
          _vehicleMakeController.text = vehicleDetails['make'] ?? '';
          _vehicleModelController.text = vehicleDetails['model'] ?? '';
          _vehicleYearController.text =
              vehicleDetails['year']?.toString() ?? '';
          _vehicleColorController.text = vehicleDetails['color'] ?? '';
          _vehicleLicensePlateController.text =
              vehicleDetails['licensePlate'] ?? '';

          // License info
          final licenseDetails = captainData['drivingLicense'] ?? {};
          _licenseNumberController.text = licenseDetails['number'] ?? '';
          _licenseStateController.text = licenseDetails['state'] ?? '';
          _isLicenseVerified = licenseDetails['verified'] ?? false;

          if (licenseDetails['expiry'] != null) {
            _licenseExpiry = DateTime.parse(licenseDetails['expiry']);
          }

          // Statistics
          _rating = (captainData['rating'] ?? 0.0).toDouble();
          _totalRides = captainData['totalRides'] ?? 0;
          _totalEarnings = (captainData['totalEarnings'] ?? 0.0).toDouble();
          _accountStatus = captainData['accountStatus'] ?? 'pending';

          _isLoading = false;
        });
      } else {
        throw Exception('Failed to load captain data: ${response.body}');
      }
    } catch (e) {
      print('Error fetching captain data: $e');
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to fetch profile data: $e')),
        );
      }
    }
  }

  Future<void> _saveChanges() async {
    try {
      setState(() => _isLoading = true);

      // Personal info update
      final personalData = {
        'firstName': _firstNameController.text.trim(),
        'lastName': _lastNameController.text.trim(),
        'phone': _phoneController.text.trim(),
      };

      // Vehicle details update
      final vehicleData = {
        'vehicleDetails': {
          'make': _vehicleMakeController.text.trim(),
          'model': _vehicleModelController.text.trim(),
          'year': int.tryParse(_vehicleYearController.text.trim()) ?? 0,
          'color': _vehicleColorController.text.trim(),
          'licensePlate': _vehicleLicensePlateController.text.trim(),
        }
      };

      // License details update
      final licenseData = {
        'drivingLicense': {
          'number': _licenseNumberController.text.trim(),
          'state': _licenseStateController.text.trim(),
          'expiry': _licenseExpiry?.toIso8601String(),
        }
      };

      // Combine all updates
      final updateData = {
        ...personalData,
        ...vehicleData,
        ...licenseData,
      };

      final response = await http.put(
        Uri.parse('http://10.0.2.2:3000/api/captain/profile'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.token}',
        },
        body: jsonEncode(updateData),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Profile updated successfully'),
              backgroundColor: Colors.green,
            ),
          );
          setState(() => _isEditing = false);
          _fetchCaptainData(); // Refresh data
        }
      } else {
        throw Exception('Failed to update profile: ${response.body}');
      }
    } catch (e) {
      print('Update error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update profile: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _pickImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? pickedFile = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 85,
      );

      if (pickedFile != null) {
        setState(() => _isUploading = true);

        // Upload to Supabase
        final String supabaseUrl =
            await SupabaseManager.uploadImage(File(pickedFile.path));

        // Update profile image in MongoDB
        final response = await http.put(
          Uri.parse('http://10.0.2.2:3000/api/captain/update-profile-image'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${widget.token}',
          },
          body: jsonEncode({'profileImageUrl': supabaseUrl}),
        );

        if (response.statusCode == 200) {
          setState(() => _profileImage = supabaseUrl);
          await _fetchCaptainData(); // Refresh data
        } else {
          throw Exception('Failed to update profile image');
        }
      }
    } catch (e) {
      print('Image upload error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to upload image: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _isUploading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        final primaryCaptainColor = themeProvider.isDarkMode
            ? DarkColors.primaryCaptain
            : LightColors.primaryCaptain;
        final backgroundColor = themeProvider.isDarkMode
            ? DarkColors.background
            : LightColors.background;
        final textColor =
            themeProvider.isDarkMode ? DarkColors.text : LightColors.text;

        return Scaffold(
          backgroundColor: backgroundColor,
          appBar: AppBar(
            elevation: 0,
            title: Text(
              'Captain Profile',
              style: TextStyle(color: Colors.white),
            ),
            backgroundColor: primaryCaptainColor,
            actions: [
              IconButton(
                icon: Icon(
                  _isEditing ? Icons.save_rounded : Icons.edit_rounded,
                  color: Colors.white,
                ),
                onPressed: () {
                  if (_isEditing) {
                    _saveChanges();
                  }
                  setState(() => _isEditing = !_isEditing);
                },
              ),
            ],
            bottom: TabBar(
              controller: _tabController,
              indicatorColor: Colors.white,
              tabs: const [
                Tab(text: 'Profile'),
                Tab(text: 'Vehicle'),
                Tab(text: 'License'),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: [
              _isLoading
                  ? Center(
                      child:
                          CircularProgressIndicator(color: primaryCaptainColor))
                  : _buildProfileTab(themeProvider),
              _isLoading
                  ? Center(
                      child:
                          CircularProgressIndicator(color: primaryCaptainColor))
                  : _buildVehicleTab(themeProvider),
              _isLoading
                  ? Center(
                      child:
                          CircularProgressIndicator(color: primaryCaptainColor))
                  : _buildLicenseTab(themeProvider),
            ],
          ),
          bottomNavigationBar: CaptainNavBar(
            currentIndex: 3,
            userId: widget.userId,
            token: widget.token,
          ),
        );
      },
    );
  }

  Widget _buildProfileTab(ThemeProvider themeProvider) {
    final primaryCaptainColor = themeProvider.isDarkMode
        ? DarkColors.primaryCaptain
        : LightColors.primaryCaptain;
    final cardColor =
        themeProvider.isDarkMode ? DarkColors.surface : LightColors.surface;

    return SingleChildScrollView(
      child: Column(
        children: [
          // Header with profile image
          Container(
            padding: const EdgeInsets.only(top: 20, bottom: 30),
            decoration: BoxDecoration(
              color: primaryCaptainColor,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Center(
              child: Column(
                children: [
                  ProfileImageHero(
                    imageUrl: _profileImage,
                    radius: 60,
                    heroTag: 'captain-${widget.userId}',
                    showEditButton: _isEditing,
                    isLoading: _isUploading,
                    onEdit: _pickImage,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "${_firstNameController.text} ${_lastNameController.text}",
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        _emailController.text,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white.withOpacity(0.9),
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(
                        _isEmailVerified
                            ? Icons.verified_rounded
                            : Icons.error_outline_rounded,
                        color: _isEmailVerified
                            ? Colors.greenAccent
                            : Colors.redAccent,
                        size: 16,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Captain Statistics
          Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              color: cardColor,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Captain Statistics',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatItem(
                          icon: Icons.star,
                          value: _rating.toString(),
                          label: 'Rating',
                          color: Colors.amber,
                        ),
                        _buildStatItem(
                          icon: Icons.directions_car,
                          value: _totalRides.toString(),
                          label: 'Rides',
                          color: Colors.blue,
                        ),
                        _buildStatItem(
                          icon: Icons.currency_rupee,
                          value: _totalEarnings.toStringAsFixed(0),
                          label: 'Earnings',
                          color: Colors.green,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text('Account Status: '),
                        Chip(
                          label: Text(_accountStatus),
                          backgroundColor: _getStatusColor(_accountStatus),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Personal Information
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Personal Information',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),

                // First Name
                _buildTextField(
                  controller: _firstNameController,
                  label: 'First Name',
                  icon: Icons.person,
                  enabled: _isEditing,
                ),

                // Last Name
                _buildTextField(
                  controller: _lastNameController,
                  label: 'Last Name',
                  icon: Icons.person,
                  enabled: _isEditing,
                ),

                // Email
                _buildTextField(
                  controller: _emailController,
                  label: 'Email',
                  icon: Icons.email,
                  enabled: false, // Email can't be edited
                  suffix: Icon(
                    _isEmailVerified ? Icons.verified : Icons.info_outline,
                    color: _isEmailVerified ? Colors.green : Colors.orange,
                  ),
                ),

                // Phone
                _buildTextField(
                  controller: _phoneController,
                  label: 'Phone',
                  icon: Icons.phone,
                  enabled: _isEditing,
                ),

                if (_isEditing)
                  Padding(
                    padding: const EdgeInsets.only(top: 24),
                    child: SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _saveChanges,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryCaptainColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _isLoading
                            ? CircularProgressIndicator(color: Colors.white)
                            : Text(
                                'Save Changes',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVehicleTab(ThemeProvider themeProvider) {
    final primaryCaptainColor = themeProvider.isDarkMode
        ? DarkColors.primaryCaptain
        : LightColors.primaryCaptain;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Vehicle Information',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Vehicle Make
          _buildTextField(
            controller: _vehicleMakeController,
            label: 'Make',
            icon: Icons.directions_car,
            enabled: _isEditing,
          ),

          // Vehicle Model
          _buildTextField(
            controller: _vehicleModelController,
            label: 'Model',
            icon: Icons.directions_car_filled,
            enabled: _isEditing,
          ),

          // Vehicle Year
          _buildTextField(
            controller: _vehicleYearController,
            label: 'Year',
            icon: Icons.date_range,
            enabled: _isEditing,
            keyboardType: TextInputType.number,
          ),

          // Vehicle Color
          _buildTextField(
            controller: _vehicleColorController,
            label: 'Color',
            icon: Icons.color_lens,
            enabled: _isEditing,
          ),

          // License Plate
          _buildTextField(
            controller: _vehicleLicensePlateController,
            label: 'License Plate',
            icon: Icons.badge,
            enabled: _isEditing,
          ),

          if (_isEditing)
            Padding(
              padding: const EdgeInsets.only(top: 24),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveChanges,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryCaptainColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text(
                          'Save Vehicle Information',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildLicenseTab(ThemeProvider themeProvider) {
    final primaryCaptainColor = themeProvider.isDarkMode
        ? DarkColors.primaryCaptain
        : LightColors.primaryCaptain;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'License Information',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Chip(
                label: Text(_isLicenseVerified ? 'Verified' : 'Pending'),
                backgroundColor: _isLicenseVerified
                    ? Colors.green.shade100
                    : Colors.orange.shade100,
                labelStyle: TextStyle(
                  color: _isLicenseVerified
                      ? Colors.green.shade800
                      : Colors.orange.shade800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // License Number
          _buildTextField(
            controller: _licenseNumberController,
            label: 'License Number',
            icon: Icons.credit_card,
            enabled: _isEditing,
          ),

          // License State
          _buildTextField(
            controller: _licenseStateController,
            label: 'State',
            icon: Icons.location_on,
            enabled: _isEditing,
          ),

          // License Expiry
          GestureDetector(
            onTap: _isEditing
                ? () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: _licenseExpiry ??
                          DateTime.now().add(Duration(days: 365)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(Duration(days: 365 * 10)),
                    );
                    if (picked != null) {
                      setState(() => _licenseExpiry = picked);
                    }
                  }
                : null,
            child: AbsorbPointer(
              child: _buildTextField(
                controller: TextEditingController(
                  text: _licenseExpiry != null
                      ? intl.DateFormat('dd/MM/yyyy').format(_licenseExpiry!)
                      : '',
                ),
                label: 'Expiry Date',
                icon: Icons.calendar_today,
                enabled: _isEditing,
                hintText: 'Select expiry date',
              ),
            ),
          ),

          if (_isEditing)
            Padding(
              padding: const EdgeInsets.only(top: 24),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveChanges,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryCaptainColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: _isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text(
                          'Save License Information',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool enabled = true,
    Widget? suffix,
    String? hintText,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        enabled: enabled,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          hintText: hintText,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          prefixIcon: Icon(icon),
          suffixIcon: suffix,
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'active':
        return Colors.green.shade100;
      case 'pending':
        return Colors.orange.shade100;
      case 'suspended':
        return Colors.red.shade100;
      default:
        return Colors.grey.shade100;
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _vehicleMakeController.dispose();
    _vehicleModelController.dispose();
    _vehicleYearController.dispose();
    _vehicleColorController.dispose();
    _vehicleLicensePlateController.dispose();
    _licenseNumberController.dispose();
    _licenseStateController.dispose();
    _tabController.dispose();
    super.dispose();
  }
}
