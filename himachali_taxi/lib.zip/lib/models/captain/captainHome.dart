import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:himachali_taxi/models/captain/captainNavBAr.dart';
import 'package:himachali_taxi/models/rides/captain_ride_request.dart';
import 'package:himachali_taxi/utils/themes/colors.dart';
import 'package:himachali_taxi/utils/themes/themeprovider.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:provider/provider.dart';

class CaptainHomeScreen extends StatefulWidget {
  final String userId;
  final String token;

  const CaptainHomeScreen({
    Key? key,
    required this.userId,
    required this.token,
  }) : super(key: key);

  @override
  _CaptainHomeScreenState createState() => _CaptainHomeScreenState();
}

class _CaptainHomeScreenState extends State<CaptainHomeScreen> {
  GoogleMapController? mapController;
  bool isAvailable = false;
  bool _isLoading = false;
  IO.Socket? socket;

  @override
  void initState() {
    super.initState();
    _initSocket();
  }

  void _initSocket() {
    try {
      socket = IO.io('http://10.0.2.2:3000', <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
        'extraHeaders': {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.token}',
        },
      });

      socket!.connect();
      socket!.onConnect((_) {
        print('Socket connected');
        socket!.emit('captainConnected', {'captainId': widget.userId});
        _setupSocketListeners();
      });

      socket!.onError((data) => print('Socket error: $data'));
      socket!.onDisconnect((_) => print('Socket disconnected'));
    } catch (e) {
      print('Socket initialization error: $e');
    }
  }

  void _setupSocketListeners() {
    socket!.on('rideRequest', (data) {
      print('Received ride request: $data');
      if (data != null && mounted) {
        try {
          final rideRequest = CaptainRideRequest.fromJson(data);
          _showRideRequestDialog(rideRequest);
        } catch (e) {
          print('Error parsing ride request: $e');
        }
      }
    });

    socket!.on('rideCancelled', (data) {
      print('Ride cancelled: $data');
      if (mounted) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ride request was cancelled by the passenger'),
            backgroundColor: Colors.orange,
          ),
        );
      }
    });

    socket!.on('paymentCompleted', (data) {
      print('Payment completed: $data');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Payment received for your ride'),
            backgroundColor: Colors.green,
          ),
        );
      }
    });
  }

  void _showRideRequestDialog(CaptainRideRequest rideRequest) {
    if (!mounted) return;

    final ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    final primaryCaptainColor = themeProvider.isDarkMode
        ? DarkColors.primaryCaptain
        : LightColors.primaryCaptain;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.notifications_active, color: primaryCaptainColor),
            SizedBox(width: 8),
            Text('New Ride Request'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.person),
                  backgroundColor: primaryCaptainColor.withOpacity(0.2),
                ),
                title: Text(rideRequest.passengerName),
                subtitle: Row(
                  children: [
                    Icon(Icons.star, size: 16, color: Colors.amber),
                    Text(' ${rideRequest.passengerRating.toStringAsFixed(1)}'),
                  ],
                ),
                trailing:
                    Text('₹${rideRequest.estimatedFare.toStringAsFixed(0)}',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        )),
              ),
              Divider(),
              _buildLocationItem(
                icon: Icons.my_location,
                title: 'Pickup',
                address: rideRequest.pickupAddress,
                color: Colors.green,
              ),
              SizedBox(height: 8),
              _buildLocationItem(
                icon: Icons.location_on,
                title: 'Dropoff',
                address: rideRequest.dropoffAddress,
                color: Colors.red,
              ),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildDetailItem(
                    icon: Icons.route,
                    value:
                        '${rideRequest.estimatedDistance.toStringAsFixed(1)} km',
                    label: 'Distance',
                  ),
                  _buildDetailItem(
                    icon: Icons.timer,
                    value:
                        '${(rideRequest.estimatedDuration / 60).round()} min',
                    label: 'Duration',
                  ),
                  _buildDetailItem(
                    icon: Icons.payment,
                    value: rideRequest.paymentMethod,
                    label: 'Payment',
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Center(
                  child: Text(
                    'Auto-declining in ${20 - DateTime.now().difference(rideRequest.requestTime).inSeconds} seconds',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => _declineRideRequest(rideRequest.id),
            child: Text('DECLINE', style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () => _acceptRideRequest(rideRequest.id),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryCaptainColor,
            ),
            child: Text('ACCEPT'),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationItem({
    required IconData icon,
    required String title,
    required String address,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 24),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
              Text(address, style: TextStyle(fontSize: 13)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDetailItem({
    required IconData icon,
    required String value,
    required String label,
  }) {
    return Column(
      children: [
        Icon(icon, size: 20, color: Colors.grey),
        SizedBox(height: 4),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold)),
        Text(label, style: TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }

  void _acceptRideRequest(String rideId) {
    try {
      socket?.emit('acceptRideRequest', {
        'captainId': widget.userId,
        'rideId': rideId,
      });

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Ride accepted! Navigating to pickup...'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      print('Error accepting ride: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to accept ride: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _declineRideRequest(String rideId) {
    try {
      socket?.emit('declineRideRequest', {
        'captainId': widget.userId,
        'rideId': rideId,
      });

      if (mounted) {
        Navigator.of(context).pop();
      }
    } catch (e) {
      print('Error declining ride: $e');
    }
  }

  void _toggleAvailability(bool value) {
    try {
      setState(() {
        isAvailable = value;
        _isLoading = true;
      });

      socket?.emit('updateCaptainAvailability',
          {'captainId': widget.userId, 'isAvailable': value});

      Future.delayed(Duration(seconds: 1), () {
        if (mounted) {
          setState(() => _isLoading = false);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(value
                  ? 'You are now available for rides'
                  : 'You are now offline'),
              duration: Duration(seconds: 2),
            ),
          );
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update status: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        final onPrimaryCaptainColor = themeProvider.isDarkMode
            ? DarkColors.onPrimaryCaptain
            : LightColors.onPrimaryCaptain;
        final primaryCaptainColor = themeProvider.isDarkMode
            ? DarkColors.primaryCaptain
            : LightColors.primaryCaptain;

        return Scaffold(
          appBar: AppBar(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 40,
                  width: 40,
                  child: Image.asset(
                    "assets/images/taxilogo.png",
                    fit: BoxFit.contain,
                  ),
                ),
                SizedBox(width: 12),
                Text(
                  "Captain Dashboard",
                  style: TextStyle(color: onPrimaryCaptainColor),
                ),
              ],
            ),
            backgroundColor: primaryCaptainColor,
            actions: [
              Stack(
                alignment: Alignment.center,
                children: [
                  Switch(
                    value: isAvailable,
                    activeColor: Colors.green,
                    activeTrackColor: Colors.green.withOpacity(0.5),
                    inactiveThumbColor: Colors.grey,
                    inactiveTrackColor: Colors.grey.withOpacity(0.5),
                    onChanged: _isLoading ? null : _toggleAvailability,
                  ),
                  if (_isLoading)
                    Positioned(
                      right: 10,
                      child: SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: onPrimaryCaptainColor,
                        ),
                      ),
                    ),
                ],
              ),
              SizedBox(width: 8),
            ],
          ),
          body: _buildHomeMapView(themeProvider),
          bottomNavigationBar: CaptainNavBar(
            currentIndex: 0,
            userId: widget.userId,
            token: widget.token,
          ),
        );
      },
    );
  }

  Widget _buildHomeMapView(ThemeProvider themeProvider) {
    return Stack(
      children: [
        GoogleMap(
          onMapCreated: (GoogleMapController controller) {
            mapController = controller;
          },
          initialCameraPosition: CameraPosition(
            target: LatLng(31.1048, 77.1734),
            zoom: 11.0,
          ),
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          mapToolbarEnabled: true,
          zoomControlsEnabled: true,
          compassEnabled: true,
        ),
        Positioned(
          top: 16,
          left: 16,
          right: 16,
          child: Card(
            color: themeProvider.isDarkMode
                ? DarkColors.surface
                : LightColors.surface,
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isAvailable ? 'You are online' : 'You are offline',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: themeProvider.isDarkMode
                          ? DarkColors.text
                          : LightColors.text,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    isAvailable
                        ? 'You\'re visible to nearby passengers'
                        : 'Go online to receive ride requests',
                    style: TextStyle(
                      fontSize: 14,
                      color: themeProvider.isDarkMode
                          ? DarkColors.subtext
                          : LightColors.subtext,
                    ),
                  ),
                  SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isLoading
                          ? null
                          : () => _toggleAvailability(!isAvailable),
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            isAvailable ? Colors.red : Colors.green,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: _isLoading
                          ? SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              isAvailable ? 'Go Offline' : 'Go Online',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    try {
      print('Disposing CaptainHomeScreen resources');
      if (socket != null && socket!.connected) {
        socket!.emit('captainDisconnected', {'captainId': widget.userId});
        socket!.disconnect();
        socket!.dispose();
        print('Socket disconnected and disposed');
      }

      if (mapController != null) {
        mapController!.dispose();
        print('Map controller disposed');
      }
    } catch (e) {
      print('Error during dispose: $e');
    } finally {
      super.dispose();
    }
  }
}
