import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:himachali_taxi/models/user/bottom_navigation_bar.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import '../../utils/themes/themeprovider.dart';
import '../../utils/themes/colors.dart';

class HomeScreen extends StatefulWidget {
  final String userId;
  final String token;

  const HomeScreen({Key? key, required this.userId, required this.token})
      : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();
  GoogleMapController? _mapController;
  LocationData? _currentLocation;
  Set<Marker> _markers = {};
  bool _isLoading = true;

  static const CameraPosition _defaultPosition = CameraPosition(
    target: LatLng(32.2245, 76.1566), // Himachal Pradesh coordinates
    zoom: 15,
  );

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    final location = Location();
    bool serviceEnabled;
    PermissionStatus permissionGranted;

    try {
      serviceEnabled = await location.serviceEnabled();
      if (!serviceEnabled) {
        serviceEnabled = await location.requestService();
        if (!serviceEnabled) return;
      }

      permissionGranted = await location.hasPermission();
      if (permissionGranted == PermissionStatus.denied) {
        permissionGranted = await location.requestPermission();
        if (permissionGranted != PermissionStatus.granted) return;
      }

      setState(() => _isLoading = true);

      final locationData = await location.getLocation();
      setState(() {
        _currentLocation = locationData;
        _markers.add(
          Marker(
            markerId: const MarkerId('current_location'),
            position: LatLng(locationData.latitude!, locationData.longitude!),
            infoWindow: const InfoWindow(title: 'Your Location'),
          ),
        );
        _isLoading = false;
      });

      _mapController?.animateCamera(
        CameraUpdate.newLatLng(
          LatLng(locationData.latitude!, locationData.longitude!),
        ),
      );
    } catch (e) {
      print('Error getting location: $e');
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final primaryColor =
        themeProvider.isDarkMode ? DarkColors.primary : LightColors.primary;
    final onPrimaryColor =
        themeProvider.isDarkMode ? DarkColors.onPrimary : LightColors.onPrimary;
    final dividerColor =
        themeProvider.isDarkMode ? DarkColors.divider : LightColors.divider;
    final textColor =
        themeProvider.isDarkMode ? DarkColors.text : LightColors.text;
    final subtextColor =
        themeProvider.isDarkMode ? DarkColors.subtext : LightColors.subtext;
    final shadowColor =
        themeProvider.isDarkMode ? DarkColors.shadow : LightColors.shadow;
    final surfaceColor =
        themeProvider.isDarkMode ? DarkColors.surface : LightColors.surface;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 40,
              width: 40,
              child: Image.asset(
                "assets/images/taxilogo.png",
                fit: BoxFit.contain,
              ),
            ),
            const SizedBox(width: 20),
            Text(
              "Himachali Taxi",
              style: TextStyle(color: onPrimaryColor),
            ),
          ],
        ),
        backgroundColor: primaryColor,
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: _defaultPosition,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            markers: _markers,
            onMapCreated: (GoogleMapController controller) {
              _mapController = controller;
              if (_currentLocation != null) {
                controller.animateCamera(
                  CameraUpdate.newLatLng(
                    LatLng(
                      _currentLocation!.latitude!,
                      _currentLocation!.longitude!,
                    ),
                  ),
                );
              }
            },
          ),
          if (_isLoading) const Center(child: CircularProgressIndicator()),
          DraggableScrollableSheet(
            initialChildSize: 0.3,
            minChildSize: 0.2,
            maxChildSize: 0.9,
            builder: (context, scrollController) {
              return Container(
                decoration: BoxDecoration(
                  color: surfaceColor,
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(20)),
                  boxShadow: [
                    BoxShadow(
                      color: shadowColor.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 7,
                      offset: const Offset(0, -3),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Container(
                            height: 4,
                            width: 50,
                            decoration: BoxDecoration(
                              color: dividerColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Book a ride',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: textColor,
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          controller: _fromController,
                          decoration: InputDecoration(
                            labelText: 'From',
                            border: OutlineInputBorder(),
                            prefixIcon:
                                Icon(Icons.location_on, color: primaryColor),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: _destinationController,
                          decoration: InputDecoration(
                            labelText: 'Destination location',
                            border: OutlineInputBorder(),
                            prefixIcon:
                                Icon(Icons.location_on, color: primaryColor),
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).pushNamed(
                                '/ride',
                                arguments: {
                                  'from': _fromController.text,
                                  'destination': _destinationController.text,
                                  'userId': widget.userId,
                                  'token': widget.token,
                                },
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 50,
                                vertical: 15,
                              ),
                            ),
                            child: Text(
                              'Book a ride',
                              style: TextStyle(
                                  color: onPrimaryColor, fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
      bottomNavigationBar: CustomNavBar(currentIndex: 0, userId: widget.userId),
    );
  }

  @override
  void dispose() {
    _fromController.dispose();
    _destinationController.dispose();
    _mapController?.dispose();
    super.dispose();
  }
}
